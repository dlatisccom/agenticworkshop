// Metric Treadmill - modernized (no jQuery/jQuery Mobile)
// This file is an ES module so we can export pure functions for testing.

const MILES_TO_KM = 1.609344;

/** Round to 1 decimal place */
export function round1(n) {
  const num = typeof n === 'number' ? n : Number(n);
  if (!Number.isFinite(num)) return NaN;
  return Math.round(num * 10) / 10;
}

export function milesToKm(miles) {
  const m = typeof miles === 'number' ? miles : Number(String(miles).trim());
  if (!Number.isFinite(m)) return NaN;
  return m * MILES_TO_KM;
}

/**
 * Parse pace in min/mi.
 * Accepts:
 *  - "8:30" (m:ss)
 *  - "08:30" (mm:ss)
 *  - "8.5" (minutes as decimal)
 */
export function parsePaceMinPerMile(text) {
  const raw = String(text ?? '').trim();
  if (!raw) return null;

  // If user enters decimals (e.g. 8.5), treat as minutes.
  if (/^\d+(?:\.\d+)?$/.test(raw)) {
    const minutes = Number(raw);
    if (!Number.isFinite(minutes) || minutes <= 0) return null;
    return minutes;
  }

  // m:ss
  const m = raw.match(/^(\d+)\s*:\s*(\d{1,2})$/);
  if (!m) return null;

  const minutes = Number(m[1]);
  const seconds = Number(m[2]);
  if (!Number.isFinite(minutes) || !Number.isFinite(seconds)) return null;
  if (minutes < 0 || seconds < 0 || seconds >= 60) return null;

  const total = minutes + seconds / 60;
  return total > 0 ? total : null;
}

/** Convert min/mi pace to km/h */
export function minPerMileToKmPerHour(minPerMile) {
  const pace = typeof minPerMile === 'number' ? minPerMile : Number(minPerMile);
  if (!Number.isFinite(pace) || pace <= 0) return NaN;
  const milesPerHour = 60 / pace;
  const kmPerHour = milesPerHour * MILES_TO_KM;
  return kmPerHour;
}

export function paceTextToKmPerHour(paceText) {
  const minPerMile = parsePaceMinPerMile(paceText);
  if (minPerMile == null) return NaN;
  return round1(minPerMileToKmPerHour(minPerMile));
}

/**
 * Build a metric plan.
 * Returns: { items: Array<{ kms:number, kph:number, label?:string }>, warnings: string[] }
 */
export function buildMetricPlan(rpUS) {
  const warnings = [];

  const totalMiles = Number(String(rpUS.totalMiles ?? '').trim());
  const totalKm = round1(milesToKm(totalMiles));

  const easyKph = paceTextToKmPerHour(rpUS.easyPace);

  if (!Number.isFinite(totalKm) || totalKm <= 0) {
    return { items: [], warnings: [] };
  }
  if (!Number.isFinite(easyKph) || easyKph <= 0) {
    return { items: [], warnings: [] };
  }

  const numIntervals = Number(String(rpUS.numIntervals ?? '').trim());
  const intervalMiles = Number(String(rpUS.intervalMiles ?? '').trim());
  const intervalKph = paceTextToKmPerHour(rpUS.intervalPace);

  const hasIntervals =
    Number.isFinite(numIntervals) && numIntervals >= 1 &&
    Number.isFinite(intervalMiles) && intervalMiles > 0 &&
    Number.isFinite(intervalKph) && intervalKph > 0;

  /** @type {Array<{kms:number, kph:number, label?:string}>} */
  const items = [];

  if (!hasIntervals) {
    items.push({ kms: totalKm, kph: easyKph, label: 'Run' });
    return { items, warnings };
  }

  const eachIntervalKm = round1(milesToKm(intervalMiles));
  const betweenIntervalsKm = round1(eachIntervalKm / 2);
  const totalIntervalKms = round1(numIntervals * eachIntervalKm + (numIntervals - 1) * betweenIntervalsKm);

  if (totalIntervalKms > totalKm) {
    warnings.push('Intervals exceed total distance; showing intervals-only breakdown.');
  }

  const remainingKms = totalKm - totalIntervalKms;
  const warmUp = round1(Math.max(0, remainingKms / 2));
  const coolDown = round1(Math.max(0, totalKm - totalIntervalKms - warmUp));

  if (warmUp > 0) items.push({ kms: warmUp, kph: easyKph, label: 'Warm up' });

  for (let i = 0; i < numIntervals; i += 1) {
    items.push({ kms: eachIntervalKm, kph: intervalKph, label: `Interval ${i + 1}` });
    if (i < numIntervals - 1) {
      items.push({ kms: betweenIntervalsKm, kph: easyKph, label: 'Recovery' });
    }
  }

  if (coolDown > 0) items.push({ kms: coolDown, kph: easyKph, label: 'Cool down' });

  return { items, warnings };
}

function formatItem(item, cumulativeKm) {
  const kmTxt = `${item.kms.toFixed(1)} km`;
  const kphTxt = `${item.kph.toFixed(1)} km/h`;
  const labelTxt = item.label ? `${item.label}: ` : '';
  const doneAt = cumulativeKm > 0
    ? ` (done at ${(round1(cumulativeKm + item.kms)).toFixed(1)} km)`
    : '';
  return `${labelTxt}${kmTxt} @ ${kphTxt}${doneAt}`;
}

function getFormState(form) {
  const fd = new FormData(form);
  return Object.fromEntries(fd.entries());
}

function render({ items, warnings }, planEl, statusEl) {
  planEl.replaceChildren();

  if (!items.length) {
    statusEl.textContent = 'Enter easy pace and total miles to see a plan.';
    return;
  }

  statusEl.textContent = warnings.join(' ');

  let cumulative = 0;
  for (const item of items) {
    const li = document.createElement('li');
    li.textContent = formatItem(item, cumulative);
    planEl.append(li);
    cumulative += item.kms;
  }
}

function init() {
  const form = document.getElementById('form');
  const planEl = document.getElementById('runningPlan');
  const statusEl = document.getElementById('status');
  const clearBtn = document.getElementById('clear');

  if (!form || !planEl || !statusEl || !clearBtn) return;

  const recalc = () => render(buildMetricPlan(getFormState(form)), planEl, statusEl);

  // Use `input` for immediate feedback (works across modern browsers).
  form.addEventListener('input', recalc);
  form.addEventListener('change', recalc);

  clearBtn.addEventListener('click', () => {
    form.reset();
    recalc();
    // focus first field for convenience
    document.getElementById('easyPace')?.focus();
  });

  // initial state
  form.reset();
  recalc();
}

if (typeof window !== 'undefined') {
  window.addEventListener('DOMContentLoaded', init);
}
