import assert from 'node:assert/strict';
import {
  parsePaceMinPerMile,
  paceTextToKmPerHour,
  milesToKm,
  buildMetricPlan
} from '../app.js';

assert.equal(parsePaceMinPerMile('8:30'), 8.5);
assert.equal(parsePaceMinPerMile('08:30'), 8.5);
assert.equal(parsePaceMinPerMile('8.5'), 8.5);
assert.equal(parsePaceMinPerMile('8:60'), null);

assert.ok(Math.abs(milesToKm(1) - 1.609344) < 1e-9);
assert.equal(paceTextToKmPerHour('6:00'), 16.1); // 10 mph => 16.09344 kph => 16.1

{
  const { items } = buildMetricPlan({ easyPace: '8:00', totalMiles: '10' });
  assert.equal(items.length, 1);
  assert.equal(items[0].kms, 16.1);
}

{
  const { items } = buildMetricPlan({
    easyPace: '8:00',
    totalMiles: '10',
    numIntervals: '4',
    intervalMiles: '1',
    intervalPace: '6:30'
  });
  // warmup + 4 intervals + 3 recoveries + cooldown
  assert.equal(items.length, 1 + 4 + 3 + 1);
}

console.log('All tests passed.');
