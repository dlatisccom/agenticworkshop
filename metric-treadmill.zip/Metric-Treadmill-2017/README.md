# Metric Treadmill (modernized)

A tiny, dependency-free web app that converts a running plan written in **miles + min/mi pace** into **kilometers + km/h** (typical metric treadmill display).

## What changed (modernization)

- Removed **jQuery 1.9** and **jQuery Mobile 1.3** (deprecated/outdated).
- Rewrote the UI to use semantic HTML + modern responsive CSS.
- Rewrote the logic in modern JavaScript (ES module) using `addEventListener`, `FormData`, and pure functions.
- Improved input parsing/validation:
  - Pace accepts `m:ss` / `mm:ss` (e.g. `8:30`) and also decimal minutes (e.g. `8.5`).
  - Handles interval totals that exceed overall distance with a warning.

## Run

This is a static app.

### Option A: open directly

Open `index.html` in a modern browser.

### Option B: serve locally (recommended)

From the repo root:

```bash
python3 -m http.server 3000
```

Then visit http://localhost:3000

## Test

Requires Node.js 18+.

```bash
node test/app.test.mjs
```
